﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleERP.Document.API.Infrastructure.Models
{
    public class SelectItemModel
    {
        public long Id { get; set; }
        public string Title { get; set; }
    }
}
